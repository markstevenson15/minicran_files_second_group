library(testthat)
library(mockr)

test_check("mockr")
