library(testthat)
library(plotlyGeoAssets)

test_check("plotlyGeoAssets")
